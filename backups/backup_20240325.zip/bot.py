import discord
from discord.ext import commands
import openai
import nest_asyncio
import re
import os
from dotenv import load_dotenv
from settings.settings_manager import SettingsManager
from settings.conversation_manager import ConversationManager
from settings.conversation_analyzer import ConversationAnalyzer
from settings.user_manager import UserManager
from utils.integrations import get_wikipedia_summary, format_wikipedia_response, estimate_conversation_tokens
from utils.article_summarizer import ArticleSummarizer
from utils.feedback_manager import FeedbackManager
from utils.error_logger import ErrorLogger
from typing import List, Dict, Optional

# Load environment variables
load_dotenv()

# Set your API keys
openai.api_key = os.getenv("OPENAI_API_KEY")
DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN")

# Initialize managers
settings_manager = SettingsManager()
conversation_manager = ConversationManager()
conversation_analyzer = ConversationAnalyzer(settings_manager.settings_dir)
user_manager = UserManager(settings_manager.settings_dir)
article_summarizer = ArticleSummarizer()
feedback_manager = FeedbackManager(settings_manager.settings_dir)
error_logger = ErrorLogger(settings_manager.settings_dir)

# Initialize bot with intents
intents = discord.Intents.default()
intents.message_content = True  # Enable message content intent
intents.members = True  # Enable members intent
intents.guilds = True  # Enable guilds intent

# Initialize bot with sharding disabled
bot = commands.Bot(
    command_prefix='!',
    intents=intents,
    shard_count=None  # Disable sharding
)

async def send_markdown_long_message(ctx, message, chunk_size=2000):
    # If the whole message is short enough, send it directly.
    if len(message) <= chunk_size:
        await ctx.send(message)
        return

    # Split the message into lines, preserving the newline characters.
    lines = message.splitlines(keepends=True)
    current_chunk = ""
    for line in lines:
        # If adding the next line would exceed the chunk size...
        if len(current_chunk) + len(line) > chunk_size:
            # If the current chunk isn't empty, send it.
            if current_chunk:
                await ctx.send(current_chunk)
                current_chunk = ""
            # If a single line is too long, split it by characters.
            while len(line) > chunk_size:
                await ctx.send(line[:chunk_size])
                line = line[chunk_size:]
            # Start a new chunk with the remainder of the line.
            current_chunk = line
        else:
            current_chunk += line

    # Send any remaining text.
    if current_chunk:
        await ctx.send(current_chunk)

async def process_question(question: str, language: str = None, guild_id: int = None, user_id: str = None, conversation_history: List[Dict] = None):
    try:
        # Get server settings
        settings = settings_manager.get_server_settings(guild_id) if guild_id else settings_manager.default_settings
        
        # Get or create user's bespoke persona and history
        if user_id:
            bespoke_persona = user_manager.get_or_create_bespoke_persona(user_id)
            user_history = user_manager.get_or_create_user_history(user_id)
        
        # Check for user's preferred persona
        if user_id:
            preferred_persona = user_manager.get_user_preferred_persona(user_id)
            if preferred_persona:
                settings["current_persona"] = preferred_persona
        
        # Get current persona settings
        current_persona = settings.get("current_persona", "default")
        personas = settings.get("personas", {})
        persona = personas.get(current_persona, personas.get("default", {}))
        
        # Prepare messages for the API
        messages = []
        
        # Add personality prompt
        personality_prompt = []
        
        # Add role
        if "role" in persona:
            personality_prompt.append(persona["role"])
        
        # Add traits
        if "traits" in persona and persona["traits"]:
            traits = ", ".join(persona["traits"])
            personality_prompt.append(f"You have the following traits: {traits}.")
        
        # Add style
        if "style" in persona and persona["style"] != "neutral":
            personality_prompt.append(f"Your communication style is {persona['style']}.")
        
        # Add the personality prompt as a system message
        if personality_prompt:
            messages.append({
                "role": "system",
                "content": " ".join(personality_prompt)
            })
        
        # Get user's interaction history if available
        if user_id:
            # Get the last few interactions (limited by max_history)
            max_history = user_history.get("settings", {}).get("max_history", 5)
            recent_interactions = user_manager.get_user_history(user_id, max_history)
            
            # Add recent interactions to the conversation
            for interaction in recent_interactions:
                data = interaction["data"]
                messages.append({"role": "user", "content": data["question"]})
                messages.append({"role": "assistant", "content": data["response"]})
        
        # Add conversation history if available
        if conversation_history:
            # Check for topic change
            if conversation_analyzer.detect_topic_change(conversation_history):
                # Generate summary of previous topic
                summary = conversation_analyzer.generate_summary(conversation_history)
                conversation_analyzer.save_summary(guild_id, summary)
                conversation_history = []  # Clear history for new topic
            
            # Manage context window
            messages.extend(conversation_analyzer.manage_context_window(conversation_history))
        
        # Add the user's question
        messages.append({"role": "user", "content": question})

        # Call the ChatGPT API with the cleaned question
        response = openai.ChatCompletion.create(
            model=settings.get("model", "gpt-4"),
            messages=messages,
            max_tokens=settings.get("max_tokens", 2000),
            temperature=settings.get("temperature", 0.7)
        )
        full_response = response.choices[0].message['content']

        # Extract all code blocks (if any)
        code_blocks = re.findall(r"```(?:\w+)?\n(.*?)\n```", full_response, re.DOTALL)
        if code_blocks:
            extracted_code = code_blocks[-1].strip()  # Use the last code block
            # Remove code blocks from the full response to obtain commentary
            commentary = re.sub(r"```(?:\w+)?\n(.*?)\n```", "", full_response, flags=re.DOTALL).strip()
        else:
            extracted_code = ""
            commentary = full_response.strip()

        # Format the code block if code exists
        if extracted_code:
            if language:
                formatted_code = f"```{language}\n{extracted_code}\n```"
            else:
                formatted_code = f"```\n{extracted_code}\n```"
        else:
            formatted_code = ""

        # Combine commentary and code block into the final message
        if commentary and formatted_code:
            final_message = f"{commentary}\n\n{formatted_code}"
        elif commentary:
            final_message = commentary
        else:
            final_message = formatted_code

        # Update user history with the interaction
        if user_id:
            interaction_data = {
                "question": question,
                "response": final_message,
                "language": language,
                "code_present": bool(extracted_code)
            }
            user_manager.update_user_history(user_id, interaction_data)

        return final_message
    except Exception as e:
        print(f"Error: {e}")
        return "There was an error processing your request."

class PersonaSelect(discord.ui.Select):
    def __init__(self, personas: List[str], user_id: str):
        self.user_id = user_id
        options = [
            discord.SelectOption(
                label=persona,
                description=f"Switch to {persona} persona",
                value=persona
            ) for persona in personas
        ]
        super().__init__(
            placeholder="Choose a persona...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        selected_persona = self.values[0]
        user_manager.set_user_preferred_persona(self.user_id, selected_persona)
        await interaction.response.send_message(f"✅ Your preferred persona has been set to: **{selected_persona}**", ephemeral=True)

class PersonaView(discord.ui.View):
    def __init__(self, personas: List[str], user_id: str):
        super().__init__()
        self.add_item(PersonaSelect(personas, user_id))

    async def on_timeout(self):
        # Disable the select menu when the view times out
        for item in self.children:
            item.disabled = True

def setup_bot():
    @bot.event
    async def on_ready():
        print(f'Bot is ready! Logged in as {bot.user.name}')
        print(f'Connected to {len(bot.guilds)} guilds')
        print(f'Bot ID: {bot.user.id}')
        print(f'Discord.py version: {discord.__version__}')
        
        try:
            synced = await bot.tree.sync()
            print(f"Synced {len(synced)} command(s)")
        except Exception as e:
            error_id = error_logger.log_error(
                e,
                command="on_ready",
                context={"action": "syncing_commands"}
            )
            print(f"Failed to sync commands: {e} (Error ID: {error_id})")

    @bot.event
    async def on_error(event, *args, **kwargs):
        """Global error handler for Discord events."""
        error = sys.exc_info()[1]
        error_id = error_logger.log_error(
            error,
            context={
                "event": event,
                "args": str(args),
                "kwargs": str(kwargs)
            }
        )
        print(f"Error in {event}: {error} (Error ID: {error_id})")

    @bot.tree.error
    async def on_app_command_error(interaction: discord.Interaction, error: Exception):
        """Error handler for slash commands."""
        error_id = error_logger.log_error(
            error,
            command=interaction.command.name if interaction.command else None,
            user_id=str(interaction.user.id) if interaction.user else None,
            guild_id=str(interaction.guild_id) if interaction.guild_id else None,
            context={
                "command_name": interaction.command.name if interaction.command else None,
                "options": str(interaction.data.get("options", []))
            }
        )
        
        # Send user-friendly error message
        error_message = (
            "❌ An error occurred while processing your command.\n"
            f"Error ID: {error_id}\n"
            "The error has been logged and will be reviewed."
        )
        
        if interaction.response.is_done():
            await interaction.followup.send(error_message, ephemeral=True)
        else:
            await interaction.response.send_message(error_message, ephemeral=True)

    @bot.event
    async def on_message(message):
        if message.author == bot.user:
            return

        # Check if the message is a reply to a bot message
        if message.reference and message.reference.resolved:
            referenced_message = message.reference.resolved
            if referenced_message.author == bot.user:
                # Check if the referenced message is a summary
                is_summary = any(cmd in referenced_message.content.lower() for cmd in ["**source:**", "**link:**"])
                
                # Get conversation history
                conversation_history = conversation_manager.get_conversation(message.guild.id)
                
                # If it's a reply to a summary, include the summary content in the context
                if is_summary:
                    # Extract the summary content (everything between the title and source)
                    summary_match = re.search(r"\*\*(.*?)\*\*\n\n(.*?)\n\n\*\*Source:\*\*", referenced_message.content, re.DOTALL)
                    if summary_match:
                        summary_title = summary_match.group(1)
                        summary_content = summary_match.group(2)
                        
                        # Add the summary context to the conversation
                        conversation_manager.add_message(message.guild.id, "system", f"Context from previous summary about '{summary_title}':\n{summary_content}")
                
                # Process the question with conversation history
                response = await process_question(
                    message.content,
                    None,  # Language detection not needed for replies
                    message.guild.id,
                    str(message.author.id),
                    conversation_history
                )
                
                # Format the response with the user's question
                formatted_response = f"**{message.author.name} asked:**\n{message.content}\n\n**Bot's response:**\n{response}"
                
                # Send the response
                if len(formatted_response) > 2000:
                    await send_markdown_long_message(message.channel, formatted_response)
                else:
                    await message.channel.send(formatted_response)
                
                # Update conversation history
                conversation_manager.add_message(message.guild.id, "user", message.content)
                conversation_manager.add_message(message.guild.id, "assistant", response)
                return

        # Check if the bot was mentioned
        if bot.user.mentioned_in(message):
            # Get the content after the mention
            content = message.content.replace(f'<@{bot.user.id}>', '').strip()
            
            # Detect language directive if present
            lang_match = re.search(r"%(\w+)", content)
            language = None
            if lang_match:
                language = lang_match.group(1)
                content = re.sub(r"(?:in\s+)?%\w+", "", content).strip()

            # Process the question
            response = await process_question(
                content,
                language,
                message.guild.id,
                str(message.author.id)
            )
            
            # Format the response with the user's question
            formatted_response = f"**{message.author.name} asked:**\n{content}\n\n**Bot's response:**\n{response}"
            
            # Send the response
            if len(formatted_response) > 2000:
                await send_markdown_long_message(message.channel, formatted_response)
            else:
                await message.channel.send(formatted_response)
            
            # Update conversation history
            conversation_manager.add_message(message.guild.id, "user", content)
            conversation_manager.add_message(message.guild.id, "assistant", response)
            return

        await bot.process_commands(message)

    @bot.tree.command(name="askgpt", description="Ask ChatGPT a question")
    async def askgpt(interaction: discord.Interaction, question: str):
        await interaction.response.defer()

        # Detect language directive if present
        lang_match = re.search(r"%(\w+)", question)
        language = None
        if lang_match:
            language = lang_match.group(1)
            question = re.sub(r"(?:in\s+)?%\w+", "", question).strip()

        # Get conversation history
        conversation_history = conversation_manager.get_conversation(interaction.guild_id)

        # Process the question
        response = await process_question(
            question,
            language,
            interaction.guild_id,
            str(interaction.user.id),
            conversation_history
        )

        # Format the response with the user's question
        formatted_response = f"**{interaction.user.name} asked:**\n{question}\n\n**Bot's response:**\n{response}"

        # Send the response
        if len(formatted_response) > 2000:
            await send_markdown_long_message(interaction.channel, formatted_response)
        else:
            await interaction.followup.send(formatted_response)
        
        # Update conversation history
        conversation_manager.add_message(interaction.guild_id, "user", question)
        conversation_manager.add_message(interaction.guild_id, "assistant", response)

    @bot.tree.command(name="clearconversation", description="Clear the current conversation history")
    async def clearconversation(interaction: discord.Interaction):
        """Clear the current conversation history."""
        await interaction.response.defer()

        try:
            conversation_manager.clear_conversation(interaction.guild_id)
            await interaction.followup.send("✅ Conversation history cleared!")
        except Exception as e:
            await interaction.followup.send(f"❌ Error clearing conversation: {str(e)}")

    @bot.tree.command(name="gpt_tokens", description="Show token usage for the current conversation")
    async def gpt_tokens(interaction: discord.Interaction):
        """Show token usage for the current conversation."""
        await interaction.response.defer()

        try:
            conversation_history = conversation_manager.get_conversation(interaction.guild_id)
            token_info = estimate_conversation_tokens(conversation_history)
            
            # Format the response
            response = "**Token Usage Breakdown:**\n"
            for msg in token_info["message_breakdown"]:
                response += f"- {msg['role']}: {msg['tokens']} tokens\n"
            response += f"\n**Total Tokens:** {token_info['total_tokens']}"
            
            await interaction.followup.send(response)
        except Exception as e:
            await interaction.followup.send(f"❌ Error getting token info: {str(e)}")

    @bot.tree.command(name="summarize", description="Summarize an article from a URL")
    async def summarize(interaction: discord.Interaction, url: str):
        """Summarize an article from a URL."""
        await interaction.response.defer()

        # Check for TL;DR indicators in the message
        message_content = interaction.message.content if interaction.message else ""
        tldr_indicators = ["tldr", "tl;dr", "tl dr", "too long didn't read"]
        
        # Determine summary type based on message content
        summary_type = "regular"
        if any(indicator in message_content.lower() for indicator in tldr_indicators):
            summary_type = "tldr"
        elif "detailed" in message_content.lower():
            summary_type = "detailed"

        try:
            # Get summary
            summary_data = article_summarizer.summarize_article(url, summary_type=summary_type)
            
            if not summary_data:
                await interaction.followup.send("❌ Could not summarize the article. Please check the URL and try again.")
                return

            # Format and send the summary
            summary_text = article_summarizer.format_summary(summary_data)
            
            # Split long messages if needed
            if len(summary_text) > 2000:
                parts = [summary_text[i:i+1900] for i in range(0, len(summary_text), 1900)]
                for i, part in enumerate(parts):
                    if i == 0:
                        await interaction.followup.send(part)
                    else:
                        await interaction.channel.send(part)
            else:
                await interaction.followup.send(summary_text)

        except Exception as e:
            print(f"Error in summarize command: {e}")
            await interaction.followup.send("❌ An error occurred while summarizing the article. Please try again.")

    @bot.tree.command(name="wiki", description="Get a Wikipedia summary for a topic")
    async def wiki(interaction: discord.Interaction, query: str):
        """Get a Wikipedia summary for a topic."""
        await interaction.response.defer()

        try:
            # Check for TL;DR indicators in the message
            message_content = interaction.message.content if interaction.message else ""
            tldr_indicators = ["tldr", "tl;dr", "tl dr", "too long didn't read"]
            
            # Determine summary type based on message content
            summary_type = "regular"
            if any(indicator in message_content.lower() for indicator in tldr_indicators):
                summary_type = "tldr"
            elif "detailed" in message_content.lower():
                summary_type = "detailed"

            # Check if the query is a URL
            if query.startswith(('http://', 'https://')):
                if article_summarizer.is_wikipedia_url(query):
                    summary_data = article_summarizer.summarize_article(query, summary_type=summary_type)
                    response = article_summarizer.format_summary(summary_data)
                else:
                    await interaction.followup.send("❌ Please use /summarize for non-Wikipedia URLs")
                    return
            else:
                try:
                    # Pre-process the query to better understand intent
                    processed_query = await process_question(
                        f"Given this Wikipedia search query: '{query}'\n"
                        "Please help me understand what the user is looking for and suggest a better search term. "
                        "If the query is asking for a list or collection of things, suggest a more specific search term. "
                        "If the query is ambiguous, suggest a more precise term. "
                        "Return ONLY the suggested search term, nothing else.",
                        None,
                        interaction.guild_id,
                        str(interaction.user.id),
                        []
                    )
                    
                    # Clean up the processed query
                    processed_query = processed_query.strip().strip('"').strip("'")
                    
                    # Use the processed query for Wikipedia search
                    result = get_wikipedia_summary(processed_query)
                    if result:
                        summary, url = result
                        # Adjust summary length based on type
                        if summary_type == "tldr":
                            # Take only the first 2 sentences
                            sentences = summary.split('. ')
                            summary = '. '.join(sentences[:2]) + '.'
                        elif summary_type == "detailed":
                            # Keep all sentences
                            pass
                        else:  # regular
                            # Take first 5 sentences
                            sentences = summary.split('. ')
                            summary = '. '.join(sentences[:5]) + '.'
                        
                        # Add summary type indicator if it's not a regular summary
                        type_indicator = ""
                        if summary_type == "tldr":
                            type_indicator = "**TL;DR:**\n"
                        elif summary_type == "detailed":
                            type_indicator = "**Detailed Summary:**\n"
                        
                        # Add note if the query was modified
                        query_note = ""
                        if processed_query.lower() != query.lower():
                            query_note = f"\n\n*Note: I searched for '{processed_query}' to better match your request.*"
                        
                        response = f"**{processed_query.title()}**\n\n{type_indicator}{summary}\n\n**Source:** Wikipedia\n**Link:** {url}{query_note}"
                    else:
                        raise Exception("No Wikipedia article found")
                except Exception as wiki_error:
                    print(f"Wikipedia error: {wiki_error}")
                    # Fall back to askgpt with Wikipedia context
                    await interaction.followup.send(
                        "⚠️ Couldn't find a Wikipedia article. Let me try to answer your question about this topic instead.",
                        ephemeral=True
                    )
                    
                    # Process the question with Wikipedia context
                    conversation_history = conversation_manager.get_conversation(interaction.guild_id)
                    response = await process_question(
                        f"Please provide information about {query}. If possible, include factual information similar to what you might find in a Wikipedia article.",
                        None,
                        interaction.guild_id,
                        str(interaction.user.id),
                        conversation_history
                    )
                    
                    # Format the response
                    formatted_response = f"**{interaction.user.name} asked about {query}:**\n\n{response}"
                    
                    # Send the response
                    if len(formatted_response) > 2000:
                        await send_markdown_long_message(interaction.channel, formatted_response)
                    else:
                        await interaction.channel.send(formatted_response)
                    
                    # Update conversation history
                    conversation_manager.add_message(interaction.guild_id, "user", query)
                    conversation_manager.add_message(interaction.guild_id, "assistant", response)
                    return

            # Handle long responses
            if len(response) > 2000:
                await send_markdown_long_message(interaction.channel, response)
            else:
                await interaction.followup.send(response)

        except Exception as e:
            print(f"Error in wiki command: {e}")
            await interaction.followup.send(
                "❌ An error occurred while getting Wikipedia information. Let me try to answer your question instead.",
                ephemeral=True
            )
            
            # Fall back to askgpt
            conversation_history = conversation_manager.get_conversation(interaction.guild_id)
            response = await process_question(
                f"Please provide information about {query}. If possible, include factual information similar to what you might find in a Wikipedia article.",
                None,
                interaction.guild_id,
                str(interaction.user.id),
                conversation_history
            )
            
            # Format the response
            formatted_response = f"**{interaction.user.name} asked about {query}:**\n\n{response}"
            
            # Send the response
            if len(formatted_response) > 2000:
                await send_markdown_long_message(interaction.channel, formatted_response)
            else:
                await interaction.channel.send(formatted_response)
            
            # Update conversation history
            conversation_manager.add_message(interaction.guild_id, "user", query)
            conversation_manager.add_message(interaction.guild_id, "assistant", response)

    @bot.tree.command(name="bespoke", description="Create a personalized AI assistant for yourself")
    async def bespoke(interaction: discord.Interaction):
        """Create a personalized AI assistant for yourself."""
        await interaction.response.defer()

        try:
            # Check if user already has a bespoke persona
            existing_persona = user_manager.get_bespoke_persona(str(interaction.user.id))
            if existing_persona:
                await interaction.followup.send("❌ You already have a bespoke persona! Use `/bespoke_stats` to view your persona's stats.")
                return

            # Create new bespoke persona
            persona = user_manager.create_bespoke_persona(str(interaction.user.id))
            
            response = (
                "✅ Your bespoke persona has been created!\n\n"
                "Your AI assistant will now learn from your interactions and adapt to your preferences.\n"
                "You can:\n"
                "- Use `/bespoke_stats` to view your persona's stats\n"
                "- Use `/setpersona` to switch to your bespoke persona\n"
                "- Just chat with me to help shape your persona!"
            )
            
            await interaction.followup.send(response)
        except Exception as e:
            await interaction.followup.send(f"❌ Error creating bespoke persona: {str(e)}")

    @bot.tree.command(name="bespoke_stats", description="View your bespoke persona's statistics")
    async def bespoke_stats(interaction: discord.Interaction):
        """View your bespoke persona's statistics."""
        await interaction.response.defer()

        try:
            stats = user_manager.get_user_interaction_stats(str(interaction.user.id))
            if not stats:
                await interaction.followup.send("❌ You don't have a bespoke persona yet! Use `/bespoke` to create one.")
                return

            response = (
                "**Your Bespoke Persona Stats:**\n"
                f"- Total Interactions: {stats['total_interactions']}\n"
                f"- Created: {stats['created_at']}\n"
                f"- Last Updated: {stats['last_updated']}\n"
                f"- Preferred Persona: {stats['preferred_persona'] or 'None'}"
            )
            
            await interaction.followup.send(response)
        except Exception as e:
            await interaction.followup.send(f"❌ Error getting persona stats: {str(e)}")

    @bot.tree.command(name="persona", description="Select your preferred persona from available options")
    async def persona(interaction: discord.Interaction):
        """Select your preferred persona from available options."""
        await interaction.response.defer(ephemeral=True)

        try:
            # Get server settings
            settings = settings_manager.get_server_settings(interaction.guild_id)
            personas = list(settings.get("personas", {}).keys())
            
            # Add "adaptive" as an option
            if "adaptive" not in personas:
                personas.append("adaptive")
            
            if not personas:
                await interaction.followup.send("❌ No personas are available in this server.", ephemeral=True)
                return

            # Create and send the select menu
            view = PersonaView(personas, str(interaction.user.id))
            await interaction.followup.send(
                "**Select Your Preferred Persona**\n"
                "Choose a persona from the dropdown menu below:\n\n"
                "• **adaptive**: Your personalized AI assistant that learns from your interactions\n"
                "• Other personas: Pre-defined personalities with specific traits and styles",
                view=view,
                ephemeral=True
            )

        except Exception as e:
            await interaction.followup.send(f"❌ Error selecting persona: {str(e)}", ephemeral=True)

    @bot.tree.command(name="refreshpersonas", description="Refresh the list of available personas from the personas folder")
    async def refreshpersonas(interaction: discord.Interaction):
        """Refresh the list of available personas from the personas folder."""
        await interaction.response.defer()

        try:
            # Check if user has admin permissions
            if not interaction.user.guild_permissions.administrator:
                await interaction.followup.send("❌ You need administrator permissions to refresh personas.")
                return

            # Get server settings
            settings = settings_manager.get_server_settings(interaction.guild_id)
            
            # Load custom personas
            custom_personas = settings_manager.load_custom_personas(interaction.guild_id)
            
            # Update server settings with new personas
            if "personas" not in settings:
                settings["personas"] = {}
            
            # Add new personas to settings
            for persona_id, persona_data in custom_personas.items():
                settings["personas"][persona_id] = persona_data
            
            # Save updated settings
            settings_manager.update_server_settings(interaction.guild_id, settings)
            
            # Format response with list of available personas
            persona_list = "\n".join([f"- {persona}" for persona in settings["personas"].keys()])
            response = (
                "✅ Personas refreshed successfully!\n\n"
                "**Available Personas:**\n"
                f"{persona_list}\n\n"
                "Use `/persona` to select a persona."
            )
            
            await interaction.followup.send(response)

        except Exception as e:
            await interaction.followup.send(f"❌ Error refreshing personas: {str(e)}")

    @bot.tree.command(name="tokens", description="Check your OpenAI API credit usage")
    async def check_tokens(interaction: discord.Interaction):
        """Check OpenAI API credit usage."""
        await interaction.response.defer(ephemeral=True)  # Make response private

        try:
            # Get current usage
            usage = openai.Usage.retrieve()
            
            # Calculate remaining credits
            # OpenAI charges $0.03 per 1K tokens for GPT-4
            # $5 worth of credits = 166,667 tokens (5 / 0.03 * 1000)
            total_credits = 166667  # $5 worth of tokens
            remaining_tokens = total_credits - usage.total_tokens
            remaining_dollars = (remaining_tokens / 1000) * 0.03  # Convert tokens back to dollars
            
            # Format the response
            response = (
                "**OpenAI API Credit Usage**\n\n"
                f"💰 Total Credits: $5.00\n"
                f"💸 Remaining: ${remaining_dollars:.2f}\n"
                f"📊 Used: ${5 - remaining_dollars:.2f}\n\n"
                f"📝 Token Usage:\n"
                f"- Total Tokens Used: {usage.total_tokens:,}\n"
                f"- Remaining Tokens: {remaining_tokens:,}\n\n"
                "Note: Based on GPT-4 pricing ($0.03 per 1K tokens)"
            )
            
            await interaction.followup.send(response, ephemeral=True)

        except Exception as e:
            print(f"Error checking tokens: {e}")
            await interaction.followup.send(
                "❌ Error checking API credits. Please make sure your API key is valid.",
                ephemeral=True
            )

    @bot.tree.command(name="maxhistory", description="Set the maximum number of previous interactions to remember for your persona")
    async def maxhistory(interaction: discord.Interaction, count: int):
        """Set the maximum number of previous interactions to remember for your persona."""
        await interaction.response.defer(ephemeral=True)  # Make response private

        try:
            # Validate the count
            if count < 1 or count > 30:
                await interaction.followup.send(
                    "❌ Please specify a number between 1 and 30 for max history.",
                    ephemeral=True
                )
                return

            # Update the user's max history setting
            user_id = str(interaction.user.id)
            user_manager.update_user_history_setting(user_id, "max_history", count)
            
            # Get current stats to show the change
            stats = user_manager.get_user_interaction_stats(user_id)
            
            response = (
                "✅ Max history updated successfully!\n\n"
                f"**Your Persona Settings:**\n"
                f"- Max History: {count} interactions\n"
                f"- Total Interactions: {stats['total_interactions']}\n"
                f"- Created: {stats['created_at']}\n"
                f"- Last Updated: {stats['last_updated']}\n\n"
                "Your AI assistant will now remember your {count} most recent interactions when responding."
            )
            
            await interaction.followup.send(response, ephemeral=True)

        except Exception as e:
            print(f"Error updating max history: {e}")
            await interaction.followup.send(
                "❌ Error updating max history. Please try again.",
                ephemeral=True
            )

    @bot.tree.command(name="gptfeedback", description="Provide feedback about the bot's responses")
    async def gptfeedback(interaction: discord.Interaction, feedback: str):
        """Provide feedback about the bot's responses."""
        await interaction.response.defer(ephemeral=True)  # Make response private

        try:
            # Get conversation history
            conversation_history = conversation_manager.get_conversation(interaction.guild_id)
            
            # Save feedback with context
            feedback_id = feedback_manager.save_feedback(
                str(interaction.user.id),
                feedback,
                conversation_history
            )
            
            # Format the feedback entry for display
            feedback_entry = feedback_manager.get_feedback(feedback_id)
            if feedback_entry:
                response = (
                    "✅ Thank you for your feedback! Here's what was recorded:\n\n"
                    f"**Feedback ID:** {feedback_id}\n"
                    f"**Your Message:** {feedback}\n"
                    f"**Timestamp:** {feedback_entry['timestamp']}\n"
                    f"**Context Messages:** {feedback_entry['context']['total_messages']}\n\n"
                    "Your feedback has been saved and will be reviewed to help improve the bot."
                )
            else:
                response = "❌ Error saving feedback. Please try again."
            
            await interaction.followup.send(response, ephemeral=True)

        except Exception as e:
            print(f"Error saving feedback: {e}")
            await interaction.followup.send(
                "❌ An error occurred while saving your feedback. Please try again.",
                ephemeral=True
            )

    @bot.tree.command(name="errorlog", description="View error logs (Admin only)")
    async def errorlog(interaction: discord.Interaction, error_id: Optional[str] = None):
        """View error logs (Admin only)."""
        await interaction.response.defer(ephemeral=True)

        try:
            # Check if user has admin permissions
            if not interaction.user.guild_permissions.administrator:
                await interaction.followup.send("❌ You need administrator permissions to view error logs.", ephemeral=True)
                return

            if error_id:
                # Get specific error
                error = error_logger.get_error(error_id)
                if not error:
                    await interaction.followup.send(f"❌ No error log found with ID: {error_id}", ephemeral=True)
                    return

                # Format error details
                response = (
                    f"**Error Log: {error_id}**\n\n"
                    f"**Timestamp:** {error['timestamp']}\n"
                    f"**Type:** {error['error_type']}\n"
                    f"**Message:** {error['error_message']}\n"
                    f"**Command:** {error['command'] or 'N/A'}\n"
                    f"**User:** {error['user_id'] or 'N/A'}\n"
                    f"**Guild:** {error['guild_id'] or 'N/A'}\n\n"
                    "**Suggested Fixes:**\n"
                )

                # Add immediate fixes
                if error['suggested_fixes']['immediate_fixes']:
                    response += "\n**Immediate Fixes:**\n"
                    for fix in error['suggested_fixes']['immediate_fixes']:
                        response += f"- {fix}\n"

                # Add preventive measures
                if error['suggested_fixes']['preventive_measures']:
                    response += "\n**Preventive Measures:**\n"
                    for measure in error['suggested_fixes']['preventive_measures']:
                        response += f"- {measure}\n"

                # Add improvement suggestions
                if error['suggested_fixes']['improvement_suggestions']:
                    response += "\n**Improvement Suggestions:**\n"
                    for suggestion in error['suggested_fixes']['improvement_suggestions']:
                        response += f"- {suggestion}\n"

                # Add traceback if available
                if error['traceback']:
                    response += f"\n**Traceback:**\n```\n{error['traceback']}\n```"

            else:
                # Get all errors
                errors = error_logger.get_all_errors()
                if not errors:
                    await interaction.followup.send("No error logs found.", ephemeral=True)
                    return

                # Format error list
                response = "**Recent Error Logs:**\n\n"
                for error in errors[:10]:  # Show last 10 errors
                    response += (
                        f"**ID:** {error['error_id']}\n"
                        f"**Time:** {error['timestamp']}\n"
                        f"**Type:** {error['error_type']}\n"
                        f"**Command:** {error['command'] or 'N/A'}\n"
                        f"**User:** {error['user_id'] or 'N/A'}\n"
                        "---\n"
                    )

            # Send response
            if len(response) > 2000:
                await send_markdown_long_message(interaction.channel, response)
            else:
                await interaction.followup.send(response, ephemeral=True)

        except Exception as e:
            error_id = error_logger.log_error(
                e,
                command="errorlog",
                user_id=str(interaction.user.id),
                guild_id=str(interaction.guild_id)
            )
            await interaction.followup.send(
                f"❌ Error viewing logs: {str(e)} (Error ID: {error_id})",
                ephemeral=True
            )

    return bot

def main():
    bot = setup_bot()
    bot.run(DISCORD_BOT_TOKEN)

if __name__ == "__main__":
    main() 