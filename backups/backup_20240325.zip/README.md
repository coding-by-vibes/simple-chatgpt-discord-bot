# Discord Bot with OpenAI Integration

A Discord bot that uses OpenAI's API to provide intelligent responses and article summarization capabilities.

## Features

- 🤖 OpenAI-powered responses
- 📚 Article summarization from any URL
- 🌐 Wikipedia integration
- 🎭 Multiple customizable personas per server
- 💬 Conversation history and context
- 👤 User-specific settings and preferences
- 📊 Token usage tracking
- 🔄 Automatic conversation management

## Commands

### Article Summarization
- `/summarize <url>` - Summarize any article from a URL
- `/wiki <query>` - Get a Wikipedia summary for a topic (also works with Wikipedia URLs)

### Persona Management
- `/setpersonality` - Set the bot's personality (Admin only)
- `/getpersonality` - View current personality settings
- `/setpersona <name>` - Switch to a different persona
- `/reloadpersonas` - Reload custom personas (Admin only)

### User Settings
- `/bespoke` - Create your own personalized AI assistant
- `/bespoke_stats` - View your bespoke assistant's statistics
- `/setpreferred <persona>` - Set your preferred persona

### Utility Commands
- `/gpt_tokens` - Check token usage for the current conversation
- `/clear` - Clear the current conversation history

## Article Summarization

The bot can summarize articles from any URL using OpenAI's API. For Wikipedia articles, it uses a specialized handler that can:
- Extract article content and metadata
- Generate concise summaries
- Handle disambiguation pages
- Format responses with proper markdown

### Example Usage

1. Summarize any article:
```
/summarize https://example.com/article
```

2. Get Wikipedia information:
```
/wiki Quantum Computing
```

3. Summarize a Wikipedia article directly:
```
/wiki https://en.wikipedia.org/wiki/Quantum_computing
```

## Setup

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Create a `.env` file with your API keys:
   ```
   OPENAI_API_KEY=your_openai_api_key
   DISCORD_BOT_TOKEN=your_discord_bot_token
   ```
4. Run the bot:
   ```bash
   python bot.py
   ```

## Custom Personas

Create custom personas by adding JSON files to the `settings/personas` directory. Example structure:

```json
{
    "name": "Technical Expert",
    "role": "Technical Expert",
    "traits": ["precise", "technical", "analytical"],
    "style": "formal"
}
```

## Requirements

- Python 3.8+
- discord.py>=2.0.0
- openai>=1.0.0
- python-dotenv>=0.19.0
- nest-asyncio>=1.5.1
- wikipedia>=1.4.0
- tiktoken>=0.5.1
- beautifulsoup4>=4.9.3
- requests>=2.25.1

## License

MIT License 