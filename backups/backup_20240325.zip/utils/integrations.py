import wikipedia
import re
from typing import Dict, Optional, Tuple, List
import tiktoken

def count_tokens(text: str, model: str = "gpt-4") -> int:
    """Count the number of tokens in a text string."""
    try:
        encoding = tiktoken.encoding_for_model(model)
        return len(encoding.encode(text))
    except Exception:
        # Fallback to rough estimation if tiktoken fails
        return len(text.split()) * 1.3

def get_wikipedia_summary(query: str) -> Optional[Tuple[str, str]]:
    """Get a summary of a Wikipedia article."""
    try:
        # First try to search for the page
        search_results = wikipedia.search(query, results=1)
        if not search_results:
            return None
            
        # Get the page
        page = wikipedia.page(search_results[0])
        
        # Check if this is a list article
        is_list = any(keyword in page.title.lower() for keyword in ['list of', 'timeline of', 'index of'])
        
        if is_list:
            # For list articles, get a more structured summary
            summary_parts = []
            
            # Get the introduction
            intro = wikipedia.summary(search_results[0], sentences=2)
            summary_parts.append(intro)
            
            # Get content from the page
            content = page.content
            
            # Split content into sections
            sections = content.split('\n==')
            
            # Process each section
            for section in sections[1:]:  # Skip the first part (before first ==)
                # Split section into title and content
                parts = section.split('\n', 1)
                if len(parts) != 2:
                    continue
                    
                title, content = parts
                title = title.strip()
                
                # Skip certain sections
                if any(skip in title.lower() for skip in ['references', 'further reading', 'external links', 'see also']):
                    continue
                
                # Extract bullet points or numbered items
                items = []
                for line in content.split('\n'):
                    line = line.strip()
                    if line.startswith('*') or line.startswith('#'):
                        # Clean up the line
                        line = line.lstrip('*#').strip()
                        if line and not line.startswith('==') and not line.startswith('==='):
                            items.append(line)
                
                if items:
                    # Add section with items
                    summary_parts.append(f"\n**{title}**")
                    # Limit items per section to keep it concise
                    for item in items[:5]:  # Show only first 5 items per section
                        summary_parts.append(f"• {item}")
                    if len(items) > 5:
                        summary_parts.append(f"... and {len(items) - 5} more")
            
            summary = "\n".join(summary_parts)
        else:
            # For regular articles, get a comprehensive summary
            summary = wikipedia.summary(search_results[0], sentences=10)
            
            # If the summary is too short, try to get more content
            if len(summary.split()) < 100:
                # Get the first few sections of the article
                sections = page.sections[:3]  # Get first 3 sections
                section_summaries = []
                
                for section in sections:
                    try:
                        section_summary = wikipedia.summary(f"{search_results[0]} {section}", sentences=3)
                        section_summaries.append(f"\n{section}:\n{section_summary}")
                    except:
                        continue
                
                if section_summaries:
                    summary += "".join(section_summaries)
        
        return summary, page.url
    except wikipedia.exceptions.DisambiguationError as e:
        # If there's a disambiguation page, try to get the first option
        try:
            page = wikipedia.page(e.options[0])
            summary = wikipedia.summary(e.options[0], sentences=10)
            return summary, page.url
        except:
            return None
    except:
        return None

def format_wikipedia_response(summary: str, url: str) -> str:
    """Format the Wikipedia response for Discord."""
    # Split the response into chunks if it's too long
    max_length = 1900  # Leave room for formatting
    chunks = []
    current_chunk = []
    current_length = 0
    
    for line in summary.split('\n'):
        line_length = len(line) + 1  # +1 for newline
        if current_length + line_length > max_length:
            # Join current chunk and add to chunks
            chunks.append('\n'.join(current_chunk))
            current_chunk = [line]
            current_length = line_length
        else:
            current_chunk.append(line)
            current_length += line_length
    
    # Add the last chunk
    if current_chunk:
        chunks.append('\n'.join(current_chunk))
    
    # Format the response
    response = "**Wikipedia Summary**\n\n"
    
    if len(chunks) == 1:
        response += chunks[0]
    else:
        for i, chunk in enumerate(chunks, 1):
            response += f"**Part {i}:**\n{chunk}\n\n"
    
    response += f"\n**Source:** {url}"
    return response

def estimate_conversation_tokens(messages: List[Dict], model: str = "gpt-4") -> Dict[str, int]:
    """Estimate the number of tokens in a conversation."""
    try:
        encoding = tiktoken.encoding_for_model(model)
        total_tokens = 0
        message_tokens = []
        
        for message in messages:
            # Count tokens in content
            content_tokens = len(encoding.encode(message.get("content", "")))
            
            # Count tokens in role
            role_tokens = len(encoding.encode(message.get("role", "")))
            
            # Add tokens for message structure
            message_total = content_tokens + role_tokens + 4  # 4 tokens for message structure
            message_tokens.append(message_total)
            total_tokens += message_total
        
        return {
            "total": total_tokens,
            "per_message": message_tokens,
            "model": model
        }
    except Exception as e:
        print(f"Error estimating tokens: {e}")
        return {
            "total": 0,
            "per_message": [],
            "model": model,
            "error": str(e)
        } 