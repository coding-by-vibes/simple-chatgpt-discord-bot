from typing import Dict, List, Optional
import time
from .settings_manager import SettingsManager

class ConversationManager:
    def __init__(self):
        self.conversations: Dict[int, List[Dict]] = {}
        self.last_activity: Dict[int, float] = {}
        self.settings_manager = SettingsManager()

    def get_conversation_settings(self, guild_id: int) -> Dict:
        """Get conversation settings for the current persona in the guild."""
        settings = self.settings_manager.get_server_settings(guild_id)
        current_persona = settings.get("current_persona", "default")
        personas = settings.get("personas", {})
        persona = personas.get(current_persona, personas.get("default", {}))
        
        # Get conversation settings from persona, with defaults
        conv_settings = persona.get("conversation_settings", {})
        return {
            "max_history": conv_settings.get("max_history", 10),
            "timeout_minutes": conv_settings.get("timeout_minutes", 30),
            "include_context": conv_settings.get("include_context", True)
        }

    def add_message(self, guild_id: int, role: str, content: str) -> None:
        """Add a message to the conversation history."""
        if guild_id not in self.conversations:
            self.conversations[guild_id] = []
        
        # Get conversation settings for current persona
        settings = self.get_conversation_settings(guild_id)
        max_history = settings["max_history"]
        
        # Add new message
        self.conversations[guild_id].append({
            "role": role,
            "content": content
        })
        
        # Trim history if it exceeds max_history
        if len(self.conversations[guild_id]) > max_history:
            self.conversations[guild_id] = self.conversations[guild_id][-max_history:]
        
        # Update last activity timestamp
        self.last_activity[guild_id] = time.time()

    def get_conversation(self, guild_id: int) -> List[Dict]:
        """Get the conversation history for a guild."""
        if guild_id not in self.conversations:
            return []
        
        # Get conversation settings for current persona
        settings = self.get_conversation_settings(guild_id)
        timeout_minutes = settings["timeout_minutes"]
        include_context = settings["include_context"]
        
        # Check if conversation has timed out
        if time.time() - self.last_activity[guild_id] > timeout_minutes * 60:
            self.conversations[guild_id] = []
            return []
        
        # Return conversation history if context is enabled
        return self.conversations[guild_id] if include_context else []

    def clear_conversation(self, guild_id: int) -> None:
        """Clear the conversation history for a guild."""
        if guild_id in self.conversations:
            self.conversations[guild_id] = []
        if guild_id in self.last_activity:
            self.last_activity[guild_id] = time.time()

    def is_conversation_active(self, guild_id: int) -> bool:
        """Check if there is an active conversation for a guild."""
        if guild_id not in self.conversations or not self.conversations[guild_id]:
            return False
        
        # Get conversation settings for current persona
        settings = self.get_conversation_settings(guild_id)
        timeout_minutes = settings["timeout_minutes"]
        
        # Check if conversation has timed out
        return time.time() - self.last_activity[guild_id] <= timeout_minutes * 60 